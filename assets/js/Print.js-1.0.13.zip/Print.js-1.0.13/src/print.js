/*
 * Print.js
 * http://printjs.crabbly.com
 * Version: 1.0.12
 *
 * Copyright 2017 Rodrigo Vieira (@crabbly)
 * Released under the MIT license
 * https://github.com/crabbly/Print.js/blob/master/LICENSE
 */

window.printJS = require('./js/print')
